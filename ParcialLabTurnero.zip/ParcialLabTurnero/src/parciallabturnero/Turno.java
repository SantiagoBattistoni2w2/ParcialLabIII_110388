
package parciallabturnero;


class Turno {
    
     Consulta [] consultas;

    public Turno(int cantT) {
        this.consultas= new Consulta[cantT];
    }
    public void NuevaConsulta(Consulta c){
        for (int i = 0; i < consultas.length; i++) {
            if (consultas[i]== null) {
               consultas[i]=c;
               break;
            }
        }
    }

    
    public String NombrePaciente(int num){
        String nombre="";
        
        for (int i = 0; i < consultas.length; i++) {
            if (consultas[i]!=null && consultas[i].getNumHClinica()==num) {
                nombre= consultas[i].getNomPaciente();
            }
        }
        return nombre;
    
    }
    
    
    public int cantImporte(){
        int cantImp = 0;
        for (int i = 0; i < consultas.length; i++) {
            if(consultas[i]!= null && consultas[i].getImporteCobrar()== 0){
                cantImp++;
            
            }
        }
        return cantImp;
    }
    
    
    public double promedio(){
        double promedio=0;
        int contador=0;
        int acumulador=0;
        for (int i = 0; i < consultas.length; i++) {
            if (consultas[i]!= null && consultas[i].getImporteCobrar()!=0) {
                acumulador += consultas[i].getImporteCobrar();
                contador++;
                promedio= acumulador/contador;
            }
        }
        
        return promedio;
    }
    
   
   
    
    
    
    
    
    
    
    
}
