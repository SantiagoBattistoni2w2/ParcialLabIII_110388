
package parciallabturnero;
import java.util.Scanner;

public class ParcialLabTurnero {

    public static void main(String[] args) {
        
        
        
         Scanner sc= new Scanner(System.in);
        
        System.out.println("Ingresar cantidad de consultas");
        int cantConsultas= sc.nextInt();
        
        Turno t= new Turno(cantConsultas);
        
        for (int i = 0; i < cantConsultas; i++) {
            System.out.println("ingresar numero de historia clinica");
            int numHClinica=sc.nextInt();
            sc.nextLine();
            
            System.out.println("Ingresar nombre del paciente");
            String nomPaciente= sc.nextLine();
            
            System.out.println("Ingrese importe a cobrar");
            double impAcobrar=sc.nextDouble();
          
            Consulta c= new Consulta(numHClinica,nomPaciente,impAcobrar);
            t.NuevaConsulta(c);
          
        }
        
        System.out.println("El promedio de coberturas es de:"+ t.promedio());
        
        
        System.out.println("Consultas con importe 0:"+ t.cantImporte());
        
        System.out.println("Numero de historia clinica del paciente:");
        
        int numHClinica=sc.nextInt();
        
        System.out.println("El nombre del paciente es: "+t.NombrePaciente(numHClinica).toString());
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
}
