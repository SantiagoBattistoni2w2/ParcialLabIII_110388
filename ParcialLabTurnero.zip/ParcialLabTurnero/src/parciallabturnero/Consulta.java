
package parciallabturnero;

class Consulta {
    
    
    
    
     private int numHClinica;
    private String nomPaciente;
    private double impAcobrar;
    
    

    public Consulta(int numHClinica, String nomPaciente, double impAcobrar) {
        this.numHClinica = numHClinica;
        this.nomPaciente = nomPaciente;
        this.impAcobrar = impAcobrar;
        
        
        
    }

    public int getNumHClinica() {
        return numHClinica;
    }

    public void setNumHClinica(int numHClinica) {
        this.numHClinica = numHClinica;
    }

    public String getNomPaciente() {
        return nomPaciente;
    }

    public void setNomPaciente(String nomPaciente) {
        this.nomPaciente = nomPaciente;
    }

    public double getImporteCobrar() {
        return impAcobrar;
    }

    public void setImporteCobrar(double importeCobrar) {
        this.impAcobrar = importeCobrar;
    }



    
    
    
    
    
    
    
    
    
    
}
